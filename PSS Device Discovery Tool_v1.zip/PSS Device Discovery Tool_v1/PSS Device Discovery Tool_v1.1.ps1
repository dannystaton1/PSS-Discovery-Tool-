﻿# Define the IP address range or subnet you want to scan
$ipRange = "192.168.50.1-254"  # Example: Replace with your desired range

#Device password
$username = 'admin'
$pass = ''

#$username = 'site usernname'
#$pass = 'site password'

#HTTP or HTTPS
$ssl = 'http'

$loginURI = "$ssl"+"://$copierIP/web/guest/en/websys/webArch/login.cgi"
$authURI = "$ssl"+"://$copierIP/web/guest/en/websys/webArch/authForm.cgi"

# Perform a ping sweep to identify active devices
$pingResults = Test-Connection -ComputerName (1..254 | ForEach-Object { "192.168.50.$_" }) -Count 1 -ErrorAction SilentlyContinue |
               Where-Object { $_.StatusCode -eq 0 } |
               Select-Object -ExpandProperty Address

# Create an Excel file at this path location 
$excelFilePath = "C:\Users\DStaton\OneDrive - Ricoh\Desktop"
$excel = New-Object -ComObject Excel.Application
$workbook = $excel.Workbooks.Add()
$worksheet = $workbook.Worksheets.Item(1)

# Add column headers
$worksheet.Cells.Item(1, 1) = "IP Address"
$worksheet.Cells.Item(1, 2) = "Hostname"
$worksheet.Cells.Item(1, 3) = "MAC Address"
$worksheet.Cells.Item(1, 4) = "Operating System"
$worksheet.Cells.Item(1, 5) = "Manufacturer"
$worksheet.Cells.Item(1, 6) = "IPv4 Address"
$worksheet.Cells.Item(1, 7) = "Subnet Mask"
$worksheet.Cells.Item(1, 8) = "Default Gateway"
$worksheet.Cells.Item(1, 9) = "FTP Enabled"
$worksheet.Cells.Item(1, 10) = "LPR Enabled"
$worksheet.Cells.Item(1, 11) = "RSH/RCP Enabled"
$worksheet.Cells.Item(1, 12) = "DIPRINT Enabled"
$worksheet.Cells.Item(1, 13) = "WSD Enabled"
$worksheet.Cells.Item(1, 14) = "IPP Enabled"
$worksheet.Cells.Item(1, 15) = "RHPP Enabled"
$worksheet.Cells.Item(1, 16) = "Security Settings"

# Populate the Excel sheet with device information
$row = 2
foreach ($device in $pingResults) {
    $osInfo = Get-WmiObject -ComputerName $device -Class Win32_OperatingSystem
    $networkInfo = Get-WmiObject -ComputerName $device -Class Win32_NetworkAdapterConfiguration | Where-Object { $_.IPAddress -ne $null }

    $worksheet.Cells.Item($row, 1) = $device
    $worksheet.Cells.Item($row, 2) = $osInfo.CSName
    $worksheet.Cells.Item($row, 3) = $networkInfo.MACAddress
    $worksheet.Cells.Item($row, 4) = $osInfo.Caption
    $worksheet.Cells.Item($row, 5) = $osInfo.Manufacturer
    $worksheet.Cells.Item($row, 6) = $networkInfo.IPAddress[0]
    $worksheet.Cells.Item($row, 7) = $networkInfo.IPSubnet[0]
    $worksheet.Cells.Item($row, 8) = $networkInfo.DefaultIPGateway[0]
    $worksheet.Cells.Item($row, 9) = "Yes"  # Set FTP status (modify as needed)
    $worksheet.Cells.Item($row, 10) = "Yes"  # Set LPR status (modify as needed)
    $worksheet.Cells.Item($row, 11) = "Yes"  # Set RSH/RCP status (modify as needed)
    $worksheet.Cells.Item($row, 12) = "Yes"  # Set DIPRINT status (modify as needed)
    $worksheet.Cells.Item($row, 13) = "Yes"  # Set WSD status (modify as needed)
    $worksheet.Cells.Item($row, 14) = "Yes"  # Set IPP status (modify as needed)
    $worksheet.Cells.Item($row, 15) = "Yes"  # Set RHPP status (modify as needed)
    $worksheet.Cells.Item($row, 16) = "High"  # Set security level (modify as needed)

    $row++
}

# Save and close the Excel file
$workbook.SaveAs($excelFilePath)
$workbook.Close()
$excel.Quit()

Write-Host "Device information exported to $excelFilePath"
